//Q6
let whiteSpace="\n\t Nada sheikh\t\n";
console.log(whiteSpace);
let withoutwhiteSpace=whiteSpace.trim();
console.log(withoutwhiteSpace);
