var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var magicians = ['David Copperfield', 'Dynamo', 'Penn and Teller'];
var great_magicians = [];
function show_magicians(magicians) {
    for (var _i = 0, magicians_1 = magicians; _i < magicians_1.length; _i++) {
        var magician = magicians_1[_i];
        console.log(magician);
    }
}
function make_great(magicians) {
    var great_magicians = __spreadArray([], magicians, true);
    for (var i = 0; i < great_magicians.length; i++) {
        great_magicians[i] = 'The Great ' + great_magicians[i];
    }
    return great_magicians;
}
great_magicians = make_great(magicians);
console.log('Original Magicians:');
show_magicians(magicians);
console.log('Great Magicians:');
show_magicians(great_magicians);
