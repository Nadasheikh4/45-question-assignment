let magicians = ['David Copperfield', 'Dynamo', 'Penn and Teller'];
let great_magicians = [];

function show_magicians(magicians) {
  for (let magician of magicians) {
    console.log(magician);
  }
}

function make_great(magicians) {
  let great_magicians = [...magicians];
  for (let i = 0; i < great_magicians.length; i++) {
    great_magicians[i] = 'The Great ' + great_magicians[i];
  }
  return great_magicians;
}

great_magicians = make_great(magicians);

console.log('Original Magicians:');
show_magicians(magicians);

console.log('Great Magicians:');
show_magicians(great_magicians);
