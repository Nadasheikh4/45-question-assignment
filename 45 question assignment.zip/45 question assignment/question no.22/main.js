//q 22
var car1 = {
    make: 'Toyota',
    model: 'Corolla',
    year: 2015,
    color: 'Silver',
    mileage: 75000
};
var car2 = {
    make: 'Ford',
    model: 'Mustang',
    year: 2018,
    color: 'Red',
    mileage: 30000
};
var car3 = {
    make: 'Honda',
    model: 'Civic',
    year: 2020,
    color: 'Black',
    mileage: 10000
};
var cars = [car1, car2, car3];
// Intentionally create an index error
console.log(cars[10].make); // Error: cars[10] is undefined
// Correct the error
console.log(cars[0].make); // Output: Toyota
