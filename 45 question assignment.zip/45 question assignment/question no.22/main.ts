//q 22

interface Car {
    make: string;
    model: string;
    year: number;
    color: string;
    mileage: number;
  }
  
  const car1: Car = {
    make: 'Toyota',
    model: 'Corolla',
    year: 2015,
    color: 'Silver',
    mileage: 75000
  };
  
  const car2: Car = {
    make: 'Ford',
    model: 'Mustang',
    year: 2018,
    color: 'Red',
    mileage: 30000
  };
  
  const car3: Car = {
    make: 'Honda',
    model: 'Civic',
    year: 2020,
    color: 'Black',
    mileage: 10000
  };
  
  const cars = [car1, car2, car3];
  
  // Intentionally create an index error
  console.log(cars[10].make); // Error: cars[10] is undefined
  
  // Correct the error
  console.log(cars[0].make); // Output: Toyota
