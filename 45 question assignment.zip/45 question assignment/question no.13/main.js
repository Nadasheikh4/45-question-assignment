/*Q13
Your Own Array: Think of your favorite mode of transportation,such as a
motorcycle or a car, and make a list that stores several examples.
Use your list to print a series of statements about these items,
sach as "I eould like to own a Honda motorcycle."
*/
var transportationMode = ["Toyota Corolla", "Land Cruiser Prado", "SUV"];
transportationMode.forEach(function (Mode) {
    return console.log("I would like to buy a ".concat(Mode));
});
console.log("But ".concat(transportationMode[1], " is my Dream Car"));
