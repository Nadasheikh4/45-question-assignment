/*Q13
Your Own Array: Think of your favorite mode of transportation,such as a 
motorcycle or a car, and make a list that stores several examples.
Use your list to print a series of statements about these items,
sach as "I eould like to own a Honda motorcycle."
*/
let transportationMode = ["Toyota Corolla","Land Cruiser Prado","SUV"];
transportationMode.forEach((Mode)=>
console.log(`I would like to buy a ${Mode}`)
);
console.log(`But ${transportationMode[1]} is my Dream Car`);