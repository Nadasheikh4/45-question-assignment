//question 18

// Define the array of places to visit
const placesToVisit = [
    'Saudia',
    'Malishiya',
    'Behrin',
    'Dubai',
    'Turkey'
  ];
  
  // Print the array in its original order
  console.log('Original Order:');
  console.log(placesToVisit);
  
  // Print the array in alphabetical order without modifying the actual list
  console.log('Alphabetical Order (without modifying the list):');
  console.log([...placesToVisit].sort());
  
  // Show that the array is still in its original order
  console.log('Original Order (again):');
  console.log(placesToVisit);
  
  // Print the array in reverse alphabetical order without changing the order of the original list
  console.log('Reverse Alphabetical Order (without modifying the list):');
  console.log([...placesToVisit].sort().reverse());
  
  // Show that the array is still in its original order
  console.log('Original Order (again):');
  console.log(placesToVisit);
  
  // Reverse the order of the list
  placesToVisit.reverse();
  console.log('Reversed Order:');
  console.log(placesToVisit);
  
  // Reverse the order of the list again
  placesToVisit.reverse();
  console.log('Original Order (again):');
  console.log(placesToVisit);
  
  // Sort the array so it's stored in alphabetical order
  placesToVisit.sort();
  console.log('Alphabetical Order (modifying the list):');
  console.log(placesToVisit);
  
  // Sort the array so it's stored in reverse alphabetical order
  placesToVisit.reverse();
  console.log('Reverse Alphabetical Order (modifying the list):');
  console.log(placesToVisit);