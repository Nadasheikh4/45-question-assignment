// Define the array of dinner guests
const dinnerGuests = [
    'Guest 1',
    'Guest 2',
    'Guest 3',
    'Guest 4',
    'Guest 5'
  ];
  
  // Print a message indicating the number of people you are inviting to dinner
  console.log(`I am inviting ${dinnerGuests.length} people to dinner.`);