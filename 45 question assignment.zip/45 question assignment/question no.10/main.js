//Q10
//date: 4 march-24
var whiteSpace = "\n\t Nada sheikh\t\n";
console.log(whiteSpace);
var withoutwhiteSpace = whiteSpace.trim();
console.log(withoutwhiteSpace);
