//Q10
//date: 4 march-24
let whiteSpace="\n\t Nada sheikh\t\n";
console.log(whiteSpace);
let withoutwhiteSpace=whiteSpace.trim();
console.log(withoutwhiteSpace);