function make_album(artist, title, tracks) {
    if (tracks === void 0) { tracks = 0; }
    var album = {};
    album.artist = artist;
    album.title = title;
    if (tracks > 0) {
        album.tracks = tracks;
    }
    return album;
}
console.log(make_album('Adele', '21'));
// { artist: 'Adele', title: '21' }
console.log(make_album('The Beatles', 'Sgt. Pepper\'s Lonely Hearts Club Band'));
// { artist: 'The Beatles', title: 'Sgt. Pepper\'s Lonely Hearts Club Band' }
console.log(make_album('Taylor Swift', '1989', 13));
// { artist: 'Taylor Swift', title: '1989', tracks: 13 }
