function make_album(artist, title, tracks = 0) {
    let album = {};
    album.artist = artist;
    album.title = title;
    if (tracks > 0) {
      album.tracks = tracks;
    }
    return album;
  }
  
  console.log(make_album('Adele', '21')); 
  
  
  console.log(make_album('The Beatles', 'Sgt. Pepper\'s Lonely Hearts Club Band')); 
  
  
  console.log(make_album('Taylor Swift', '1989', 13)); 
  
  
