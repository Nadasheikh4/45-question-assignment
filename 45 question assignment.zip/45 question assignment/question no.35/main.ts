let animals = ['parrot', 'cat', 'bird'];

for (let animal of animals) {
  console.log(`A ${animal} would make a great pet.`);
}

console.log('Any of these animals would make a great pet!');