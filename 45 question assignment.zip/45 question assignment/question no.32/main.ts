let current_users = ['john', 'eric', 'emily', 'david', 'admin'];
let new_users = ['john', 'JOHN', 'sarah', 'emily', 'mike'];

for (let new_user of new_users) {
  if (current_users.includes(new_user.toLowerCase())) {
    console.log(`${new_user} is already in use. Please enter a new username.`);
  } else {
    console.log(`${new_user} is available.`);
  }
}