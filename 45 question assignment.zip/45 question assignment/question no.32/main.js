var current_users = ['john', 'eric', 'emily', 'david', 'admin'];
var new_users = ['john', 'JOHN', 'sarah', 'emily', 'mike'];
for (var _i = 0, new_users_1 = new_users; _i < new_users_1.length; _i++) {
    var new_user = new_users_1[_i];
    if (current_users.includes(new_user.toLowerCase())) {
        console.log("".concat(new_user, " is already in use. Please enter a new username."));
    }
    else {
        console.log("".concat(new_user, " is available."));
    }
}
