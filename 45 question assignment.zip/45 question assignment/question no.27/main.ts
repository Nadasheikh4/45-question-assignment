// Version 1: Alien color is green
let alien_color = 'green';
if (alien_color === 'green') {
  console.log('Player earned 5 points!');
} else if (alien_color === 'yellow') {
  console.log('Player earned 10 points!');
} else if (alien_color === 'red') {
  console.log('Player earned 15 points!');
}

// Output: Player earned 5 points!

// Version 2: Alien color is yellow
//let alien_color = 'yellow';
if (alien_color === 'green') {
  console.log('Player earned 5 points!');
} else if (alien_color === 'yellow') {
  console.log('Player earned 10 points!');
} else if (alien_color === 'red') {
  console.log('Player earned 15 points!');
}

// Output: Player earned 10 points!

// Version 3: Alien color is red
let aliencolor = 'red';
if (alien_color === 'green') {
  console.log('Player earned 5 points!');
} else if (alien_color === 'yellow') {
  console.log('Player earned 10 points!');
} else if (alien_color === 'red') {
  console.log('Player earned 15 points!');
}
