// Q4
console.log("Audrey Hypburn once said", '"World IMPOSSIBLE itself say I AM Possible"');
