function make_sandwich() {
    var items = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        items[_i] = arguments[_i];
    }
    console.log('You ordered a sandwich with:');
    for (var _a = 0, items_1 = items; _a < items_1.length; _a++) {
        var item = items_1[_a];
        console.log("- ".concat(item));
    }
}
make_sandwich('turkey');
// You ordered a sandwich with:
// - turkey
make_sandwich('roast beef', 'cheddar cheese');
// You ordered a sandwich with:
// - roast beef
// - cheddar cheese
make_sandwich('cheese', 'turkey', 'avocado', 'lettuce', 'tomato');
