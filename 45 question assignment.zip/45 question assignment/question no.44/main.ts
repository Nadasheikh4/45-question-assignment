function make_sandwich(...items) {
    console.log('You ordered a sandwich with:');
    for (let item of items) {
      console.log(`- ${item}`);
    }
  }
  
  make_sandwich('turkey'); 
  // You ordered a sandwich with:
  // - turkey
  
  make_sandwich('roast beef', 'cheddar cheese'); 
  // You ordered a sandwich with:
  // - roast beef
  // - cheddar cheese
  
  make_sandwich('cheese', 'turkey', 'avocado', 'lettuce', 'tomato'); 