// Version 1: Alien color is green
let aliencolor = 'green';
if (aliencolor === 'green') {
  console.log('Player just earned 5 points!');
}



// Version 2: Alien color is not green
let alien_color :'red';
if (aliencolor === 'green') {
  console.log('Player just earned 5 points!');
}

