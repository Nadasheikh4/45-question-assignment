// Version 1: Alien color is green
var aliencolor = 'green';
if (aliencolor === 'green') {
    console.log('Player just earned 5 points!');
}
// Output: Player just earned 5 points!
// Version 2: Alien color is not green
var alien_color;
if (aliencolor === 'green') {
    console.log('Player just earned 5 points!');
}
// No output
