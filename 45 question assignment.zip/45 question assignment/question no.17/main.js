/*Q17
    Shrinking Guest List: Unfortunately, your new table won’t arrive in
     time,
     and you can only invite two guests.*/
var shrinkGuestList = ["Zainab", "sonia", "Shaista"];
console.log("".concat(shrinkGuestList[1], " is not coming"));
shrinkGuestList.splice(1, 1, "Farah");
console.log("Hey everyone! We found a bigger dinning table. Lets call \n     some more Guest");
shrinkGuestList.unshift("Sunita");
shrinkGuestList.push("Amna");
var middeguest = Math.floor(shrinkGuestList.length / 2);
shrinkGuestList.splice(middeguest, 0, "Mariam");
shrinkGuestList.forEach(function (shrinkInvitation) {
    return console.log("Hey ".concat(shrinkInvitation, ",I'd love to catch up\n      over dinner! \n      How about joing me for a delicious meal this\n       \"Satuerday\" at \"8 PM\" at \"Kababjees\". Let me know if you \n       are free"));
});
console.log("Unfortunely,new dinner table wont arrive in time for the dinner, so I have space for2 guest");
while (shrinkGuestList.length > 2) {
    var removeGuest = shrinkGuestList.pop();
    console.log("Sorry, ".concat(removeGuest, " I can't invite you to Dinner"));
}
console.log("invitation to the last 2 guest");
shrinkGuestList.forEach(function (guestInvitation) { return console.log("Hey ".concat(guestInvitation, " you are still invited for dinner")); });
shrinkGuestList.pop();
shrinkGuestList.pop();
console.log(shrinkGuestList, "Empty list");
