function make_car(manufacturer, model, ...options) {
    let car = {
      manufacturer,
      model,
    };
    for (let option of options) {
      let [key, value] = option;
      car[key] = value;
    }
    return car;
  }
  
  let car = make_car(
    'Toyota',
    'Corolla',
    ['color', 'silver'],
    ['feature', 'sunroof']
  );
  
  console.log(car);
  