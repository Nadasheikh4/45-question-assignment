//Q12
let friendName =["Nada","Farah","Hanzala","Muaaz"]
let message="I love my faimly"
console.log("Hello",friendName[0],message)
console.log("Hello", friendName[1],message)
console.log("hello", friendName[2],message)
console.log("hello", friendName[3],message)
