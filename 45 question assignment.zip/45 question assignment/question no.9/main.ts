//q9
let favorateNumber =7;
console.log ("My favorate is number",favorateNumber)