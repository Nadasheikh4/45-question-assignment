//q9
var favorateNumber = 7;
console.log("My favorate is number", favorateNumber);
