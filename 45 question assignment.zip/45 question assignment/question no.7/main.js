//Q9
var favourateNumber = 1;
console.log("my favourate number is", favourateNumber);
