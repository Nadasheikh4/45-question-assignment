
//Q9
let favourateNumber=1
console.log("my favourate number is",favourateNumber);



