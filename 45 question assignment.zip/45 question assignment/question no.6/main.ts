//Q9
let favourateNumber=7
console.log("my favourate number is",favourateNumber);


