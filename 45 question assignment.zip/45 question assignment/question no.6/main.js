//Q9
var favourateNumber = 7;
console.log("my favourate number is", favourateNumber);
