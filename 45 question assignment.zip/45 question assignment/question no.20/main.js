var countries = [
    'Pakistan',
    'Saudia',
    'Behrin',
    'Dubai',
    'Turkey',
    'France',
    'China',
    'Japan',
    'India',
    'Australia'
];
console.log(countries);
