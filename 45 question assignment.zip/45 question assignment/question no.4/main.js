//5
var famousPerson = "Audery Hypburn";
var message = "once said,'world IMPOSSIBLE itself says I AM POSSIBLE'";
console.log(famousPerson, message);
