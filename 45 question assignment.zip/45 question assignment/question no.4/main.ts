//5

 let famousPerson="Audery Hypburn";
 let message="once said,'world IMPOSSIBLE itself says I AM POSSIBLE'";
 console.log(famousPerson,message)