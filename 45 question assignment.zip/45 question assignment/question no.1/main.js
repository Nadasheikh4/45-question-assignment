//question 2
var personName = "Nada";
console.log("hello", personName, "would you like to learn typescript today");
