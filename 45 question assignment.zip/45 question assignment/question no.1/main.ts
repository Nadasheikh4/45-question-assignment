//question 2
let personName="Nada"
console.log("hello",personName,"would you like to learn typescript today")