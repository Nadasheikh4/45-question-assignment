let magicians = ['David Copperfield', ' Dynamo', 'Penn and Teller'];

function show_magicians(magicians) {
  for (let magician of magicians) {
    console.log(magician);
  }
}

show_magicians(magicians);