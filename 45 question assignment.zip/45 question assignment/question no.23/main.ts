let car = 'subaru';
console.log("Is car == 'subaru'? I predict True.")
console.log(car == 'subaru') // True

console.log("Is car == 'Toyota'? I predict False.")
console.log(car == 'Toyota') // False

let age = 25;
console.log("Is age > 18? I predict True.")
console.log(age > 18) // True

console.log("Is age < 18? I predict False.")
console.log(age < 18) // False

let name = 'muaaz';
console.log("Is name == 'John'? I predict True.")
console.log(name  == 'muaaz') // True

console.log("Is name == 'sahil'? I predict False.")
console.log(name == 'sahil') // False

let isAdmin = true;
console.log("Is isAdmin == true? I predict True.")
console.log(isAdmin == true) // True

console.log("Is isAdmin == false? I predict False.")
console.log(isAdmin == false) // False

let num = 5;
console.log("Is num > 10? I predict False.")
console.log(num > 10) // False

console.log("Is num < 10? I predict True.")
console.log(num < 10) // True


