function make_shirt(size, message) {
    if (size === void 0) { size = 'large'; }
    if (message === void 0) { message = 'I love TypeScript'; }
    console.log("The shirt is size ".concat(size, " and says \"").concat(message, "\"."));
}
make_shirt(); // large shirt with default message
make_shirt('medium'); // medium shirt with default message
make_shirt('small', 'I love JavaScript'); // small shirt with different message
