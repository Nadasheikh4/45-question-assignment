function make_shirt(size = 'large', message = 'I love TypeScript') {
    console.log(`The shirt is size ${size} and says "${message}".`);
  }
  
  make_shirt(); 
  make_shirt('medium'); 
  make_shirt('small', 'I love JavaScript'); 
  