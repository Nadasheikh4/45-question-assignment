function city_country(city, country) {
    return `${city}, ${country}`;
  }
  
  console.log(city_country('Karachi', 'Pakistan')); 
  console.log(city_country('Dammam', 'Saudia')); 
  console.log(city_country('Tokyo', 'Japan')); 
  