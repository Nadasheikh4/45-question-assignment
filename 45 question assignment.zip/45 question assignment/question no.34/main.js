var favorite_pizzas = ['pepperoni', 'fajita', 'chease lovers'];
for (var _i = 0, favorite_pizzas_1 = favorite_pizzas; _i < favorite_pizzas_1.length; _i++) {
    var pizza = favorite_pizzas_1[_i];
    console.log("I like ".concat(pizza, " pizza."));
}
console.log('I really love pizza!');
