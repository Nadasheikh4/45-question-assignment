let favorite_pizzas = ['pepperoni', 'fajita', 'chease lovers'];

for (let pizza of favorite_pizzas) {
  console.log(`I like ${pizza} pizza.`);
}

console.log('I really love pizza!');
