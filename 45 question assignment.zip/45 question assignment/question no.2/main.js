//Q3
var personName = "Nada khalil sheikh";
console.log(personName.toLowerCase());
console.log(personName.toUpperCase());
console.log(personName.charAt(0).toUpperCase() + personName.slice(1).toLowerCase());
console.log("nada\Nada\Nada");
