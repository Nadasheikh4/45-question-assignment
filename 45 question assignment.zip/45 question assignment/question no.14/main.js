/* Q14
Guest List: if you would invite anyone ,living or deceased, to dinner,
who would you invited? Make a list that includes at least three peaple
 you d
like to invite to dinner. Then use your to print a masssage to each
 person
inviting them dinner.*/
var GuestList = ["kiran", "nida", "fatima"];
GuestList.forEach(function (invitation) {
    return console.log("\"hey ".concat(invitation, ", I would love to catch up over dinner!\nHow about joining me for a delicious meal this\"Sunday\"at \"8 PM\"at \n \"kababjees\". "));
});
