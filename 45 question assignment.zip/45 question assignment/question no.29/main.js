var favorite_fruits = ['apples', 'bananas', 'oranges'];
if (favorite_fruits.includes('apples')) {
    console.log('You really like apples!');
}
if (favorite_fruits.includes('bananas')) {
    console.log('You really like bananas!');
}
if (favorite_fruits.includes('oranges')) {
    console.log('You really like oranges!');
}
if (favorite_fruits.includes('grapes')) {
    console.log('You really like grapes!');
}
if (favorite_fruits.includes('strawberries')) {
    console.log('You really like strawberries!');
}
