 /*Q16
  More Guests: You've found a bigger dinner table, so there's
   room for more guests.
   */
   let moreGuestList =["kiran","nida","fatima"];

   console.log(`${moreGuestList[1]} is not coming`)

   moreGuestList.splice(1,1,"farah")

   console.log(`Hey everyone! We found a bigger dinner table.
   lets call some more guests`);
   moreGuestList.unshift("fariha")

   moreGuestList.push("Amna")

   let middleguest: number =Math.floor(moreGuestList.length/2);

   moreGuestList.splice(middleguest,0,"Maryam" );

   moreGuestList.forEach((moreInvitation)=>
console.log (`Hey ${moreInvitation},I'd love to catch up over
    dinner
   How about joing me for a diliciousmeal this "Saterday"
    at "8 PM" at
    "Kababjees".Let me know if you're free.`))