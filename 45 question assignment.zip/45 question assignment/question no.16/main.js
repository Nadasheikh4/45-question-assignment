/*Q16
 More Guests: You've found a bigger dinner table, so there's
  room for more guests.
  */
var moreGuestList = ["kiran", "nida", "fatima"];
console.log("".concat(moreGuestList[1], " is not coming"));
moreGuestList.splice(1, 1, "farah");
console.log("Hey everyone! We found a bigger dinner table.\n   lets call some more guests");
moreGuestList.unshift("fariha");
moreGuestList.push("Amna");
var middleguest = Math.floor(moreGuestList.length / 2);
moreGuestList.splice(middleguest, 0, "Maryam");
moreGuestList.forEach(function (moreInvitation) {
    return console.log("Hey ".concat(moreInvitation, ",I'd love to catch up over\n    dinner\n   How about joing me for a diliciousmeal this \"Saterday\"\n    at \"8 PM\" at\n    \"Kababjees\".Let me know if you're free."));
});
