/*Q15
Changing Guest List: One of your guests can't make it to the dinner,
so you need to send out a new set of invitations with a replacement
 guest.*/
var newGuestList = ["kiran", "nida", "fatima"];
console.log("".concat(newGuestList[1], " is not coming"));
newGuestList.splice(1, 1, "farah");
newGuestList.forEach(function (newinvitation) {
    return console.log("Hey ".concat(newinvitation, ", I would love to catch up over dinner!\n  How about joing me for a delicious meal this\"Sunday\"at \"8 PM\"\n  at\"kababjees. Let me know if you are free. "));
});
