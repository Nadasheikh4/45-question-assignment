 /*Q15 
 Changing Guest List: One of your guests can't make it to the dinner, 
 so you need to send out a new set of invitations with a replacement
  guest.*/
  let newGuestList =["kiran","nida","fatima"];
  console.log(`${newGuestList[1]} is not coming`)
  newGuestList.splice(1,1,"farah")
  newGuestList.forEach((newinvitation)=>
console.log(`Hey ${newinvitation}, I would love to catch up over dinner!
  How about joing me for a delicious meal this"Sunday"at "8 PM"
  at"kababjees. Let me know if you are free. `),
 )