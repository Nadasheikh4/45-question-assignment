// String equality and inequality
let color = 'red';
console.log("Is color == 'red'? I predict True.")
console.log(color == 'red') // True
console.log("Is color == 'blue'? I predict False.")
console.log(color == 'blue') // False

// Tests using the lower case function
let name = 'muaaz';
console.log("Is name.toLowerCase() == 'muaaz'? I predict True.")
console.log(name.toLowerCase() == 'john') // True

// Numerical tests
let num = 5;
console.log("Is num == 5? I predict True.")
console.log(num == 5) // True
console.log("Is num > 10? I predict False.")
console.log(num > 10) // False
console.log("Is num >= 5? I predict True.")
console.log(num >= 5) // True
console.log("Is num < 10? I predict True.")
console.log(num < 10) // True
console.log("Is num <= 5? I predict True.")
console.log(num <= 5) // True

// Tests using "and" and "or" operators
let age = 25;
let isStudent = true;
console.log("Is age > 18 && isStudent == true? I predict True.")
console.log(age > 18 && isStudent == true) // True
console.log("Is age > 18 || isStudent == false? I predict True.")
console.log(age > 18 || isStudent == false) // True

// Test whether an item is in a array
let colors = ['red', 'green', 'blue'];
console.log("Is 'red' in the colors array? I predict True.")
console.log(colors.includes('red')) // True
console.log("Is 'yellow' in the colors array? I predict False.")
console.log(colors.includes('yellow')) // False

// Test whether an item is not in a array
console.log("Is 'yellow' not in the colors array? I predict True.")
console.log(!colors.includes('yellow')) // True
console.log("Is 'red' not in the colors array? I predict False.")
console.log(!colors.includes('red')) // False