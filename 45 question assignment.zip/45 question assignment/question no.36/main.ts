function make_shirt(size, message) {
    console.log(`The shirt is size ${size} and says "${message}".`);
  }
  
  make_shirt('large', 'I love coding!');