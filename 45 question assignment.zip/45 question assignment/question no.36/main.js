function make_shirt(size, message) {
    console.log("The shirt is size ".concat(size, " and says \"").concat(message, "\"."));
}
make_shirt('large', 'I love coding!');
