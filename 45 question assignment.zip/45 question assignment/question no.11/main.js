//Q11
var friendName = ["Nada", "Farah", "Hanzala", "Muaaz"];
console.log(friendName[0]);
console.log(friendName[1]);
console.log(friendName[2]);
console.log(friendName[3]);
