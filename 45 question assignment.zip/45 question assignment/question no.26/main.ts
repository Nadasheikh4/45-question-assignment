// Version 1: Alien color is green
let aliencolor = 'green';
if (aliencolor === 'green') {
  console.log('Player just earned 5 points for shooting the alien!');
} else {
  console.log('Player just earned 10 points!');
}

// Output: Player just earned 5 points for shooting the alien!

// Version 2: Alien color is not green
let alien_color = 'red';
if (alien_color === 'green') {
  console.log('Player just earned 5 points for shooting the alien!');
} else {
  console.log('Player just earned 10 points!');
}
