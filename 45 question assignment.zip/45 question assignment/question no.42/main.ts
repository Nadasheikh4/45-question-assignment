let magicians = ['David Copperfield', 'Dynamo', 'Penn and Teller'];

function show_magicians(magicians) {
  for (let magician of magicians) {
    console.log(magician);
  }
}

function make_great(magicians) {
  for (let i = 0; i < magicians.length; i++) {
    magicians[i] = 'The Great ' + magicians[i];
  }
}

make_great(magicians);
show_magicians(magicians);
